package sample.logic_bricks;

import java.util.BitSet;
import java.util.List;


    public interface Brick {
        List<int [][]> getBrickMatrix();


    }


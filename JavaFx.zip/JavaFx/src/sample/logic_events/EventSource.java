package sample.logic_events;

public enum EventSource {
    USER, THREAD
}

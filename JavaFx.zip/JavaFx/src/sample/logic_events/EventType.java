package sample.logic_events;

public enum EventType {

    DOWN,LEFT,RIGHT,ROTATE
}
